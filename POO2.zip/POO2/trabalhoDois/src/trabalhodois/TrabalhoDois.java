package trabalhodois;

// Importando a biblioteca de leitura
import java.util.Scanner;

// Criando a classe Aluno
class Aluno{
    String nome;
    float nota[] = new float[4];
    
    // Criando um metodo que calcula e retorna a media de cada aluno
    float media(){
        float media=0;
            
            // For que calcula a media
            for(int i=0; i<4; i++){
                media += nota[i];
            }
        return (media/4);
    }
    // Criando um metodo que encotra e retorna a maior nota de cada aluno
    float maior(){
        float maior = nota[0];
        
        // For que encontra a maior nota
        for(int i=0; i<4; i++){
            if(nota[i]>maior){
                maior = nota[i];
            }
        }
        return maior;   
    }
    
    // Criando um metodo que encontra e retorna menor nota de cada aluno
    float menor(){
        float menor = nota[0];
        
        // For que encontra menor nota
        for(int i=0; i<4; i++){
            if(nota[i]<menor){
                menor = nota[i];
            }
        }
        return menor;   
    }
    // Criando um metodo que diz se o aluno foi aprovado ou reprovado
    boolean estaAprovado(){
        boolean estaAprovado = false;
        
        // For que diz se o aluno foi aprovado ou reprovado
        for(int i=0; i<4; i++){
            if(media()>=60){
                estaAprovado = true;
            }
            else{
                estaAprovado = false;
            }
    }
        return estaAprovado;
    }
}

public class TrabalhoDois {

    public static void main(String[] args) {
        
        // Criando o Scanner leitura
        Scanner leitura = new Scanner(System.in);
        
        // Criando o vetor alunos do tipo Aluno
        Aluno alunos[] = new Aluno[3];
        
        // Inicializando o vetor alunos
        for(int i=0; i<3; i++){
            alunos[i] = new Aluno();
        }
        
        // Lendo o nome de cada aluno 
        for(int i=0; i<3; i++){
            System.out.println("Digite o nome do aluno "+(i+1));
            alunos[i].nome = leitura.next();
        }
        
        // Lendo as notas de cada aluno
        for(int i=0; i<3; i++){
            for(int j=0; j<4; j++){
                System.out.println("Digite as notas do aluno "+alunos[i].nome);
                alunos[i].nota[j] = leitura.nextFloat();
                
                // Verificando se o usuario digitou um numero invalido (menor que zero ou maior que cem)
                while(alunos[i].nota[j]<0 || alunos[i].nota[j]>100){
                    System.out.println("Nota invalida, digite novamente.");
                    alunos[i].nota[j] = leitura.nextFloat();
                }
            }
        }
        
        // Imprimindo a media, maior, menor nota e se o aluno foi aprovado ou reprovado
        for(int i=0; i<3; i++){
            System.out.println("Media do aluno "+alunos[i].nome+": "+alunos[i].media());
            System.out.println("Maior nota do aluno "+alunos[i].nome+": "+alunos[i].maior());
            System.out.println("Menor nota do aluno "+alunos[i].nome+": "+alunos[i].menor());
            
            if(alunos[i].estaAprovado() == true){
                System.out.println("Aluno "+alunos[i].nome+" esta aprovado.");
            }
            else{
                System.out.println("Aluno "+alunos[i].nome+" esta reprovado.");
            }
            System.out.println("");
        }
    }
}
